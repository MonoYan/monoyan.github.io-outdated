---
title: Unity学习Plus（三） 一些微小的思考
date: 2020-07-15 14:39:55
tags:

- Unity
- 暑期学习

---
今天的练习是给一个现有场景debug，以达到项目要求的效果，由于太简单了这里就不写了，写了一些关于这几天学习的思考，很微小。
<!-- more -->
## Unity官方课程 Unit 3

## 游戏实现

- 人物通过空格召唤一匹马，用马来接球
- 如果接到球，马会消失，没接到，游戏结束

太简单了就没写如何实现，写了一些思考。

## Prefab Variant 与 Original Prefab

prefab是通过一个original的prefab，可以通过很多便利，比如我们创建一个没有任何属性的“人”的original prefab，这里就可以创建很多变体

- 人的国籍
- 人的语言，声音等等

变体的prefab会继承original的全部属性，可以通过复写改掉prefab的属性，变体可以基于任何的prefab，很像代码中的继承。

## 随机数

因为普通的Random的随机数是通过时间生成的，短时间内多次调用会造成生成的随机数一直，如果我们需要改变的话可以通过

- 每生成完随机数后让线程睡眠1ms
    - thread.sleep(1);
- RNGCryptoServiceProvider(); 产生相对真的随机数
    - 使用前提：

    ```csharp
    using System.Security.Cryptography;
    using System;
    ```

    ```csharp
    byte[] randomBytes = new byte[4];
    RNGCryptoServiceProvider rngCrypto = new RNGCryptoServiceProvider();
    rangCrypo.GetBytes(randomBytes);
    int rngNum = BitConerter.ToInt32(randomBytes,0)
    //计算量很大，如果想要0-100范围的为rngNum = rngNum % 100
    ```

## Tag

通过设置Tag来达到在脚本中识别对象的问题，如果调用的话可以使用:

- gameObject.CompareTag("String")

### CompareTag比gameObject.tag的优势

由于gameObject.tag中的tag是属性，要先花时间调用一次getter来获得字符串，而CompareTag只需要调用一次内部方法，节省性能总是好的。