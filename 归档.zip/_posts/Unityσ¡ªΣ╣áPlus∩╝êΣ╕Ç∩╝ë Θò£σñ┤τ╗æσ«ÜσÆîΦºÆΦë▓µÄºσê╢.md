---
title: Unity学习Plus（一） 镜头绑定和角色控制
date: 2020-07-13 23:55:15
tags:

- Unity
- 暑期学习

---
找了找资源，最后发现Unity中文社区的内容也在蓬勃发展，于是打算双线操作，一边学习C#的进阶特性，一遍开始跟着官方的课搞一搞，本篇是关于镜头绑定以及移动控制，当然，还会有一点小tips。
<!-- more -->
## Unity 官方课程 Unit 1

## 一点微小的知识

- 按 `CTRL` 可以对transform进行微调，缺省值为0.25，可以再Grid and Snap中设置
- 按 `鼠标右键` 使用 `WASD` 可以进行视角移动，很方便
- 在 `Preferences` 中，Colors → Playmode tint，可以设置游戏在unity运行中系统页面的变化，已达到提高辨识度的效果

## 镜头绑定

```csharp
public class CameraFollow : MonoBehaviour
{
    public GameObject player;
    private Vector3 offset = new Vector3(0,5,-10);
    void Start()
    {
        
    }    
    void Update() //每一帧都会被调用
    
    }

    public void LateUpdate()
    {
        transform.position = player.transform.position + offset;
    }
}
```

## Update() 与 lateUpdate()的区别

- LateUpdate是在所有Update函数调用后被调用。这可用于调整脚本执行顺序。
    - ~~人话：lateUpadate晚于Update执行~~
    - 即使在统一帧中执行，但是Update会先执行，lateUpdate后执行
- 通过这个可以解决相机绑定gameObject造成的抖动效果

## Player移动

```csharp
public class PlayerController : MonoBehaviour
{
   
    public float speed; //private 变量在unity中不可见
    public float turnSpeed;
    public float verticalInput;
    public float horizontalInput;
    void Start()
    {
        
    }
    void Update()
    {
        verticalInput = Input.GetAxis("Vertical");//-1 1
        horizontalInput = Input.GetAxis("Horizontal");

        //Vector3.forward 决定方向 Time.deltaTime 决定在不同设备速度一样
        transform.Translate(Vector3.forward * Time.deltaTime * speed * verticalInput);
        transform.Rotate(Vector3.up,Time.deltaTime * turnSpeed * horizontalInput);//0 1 0 
    }
}
```

## 获得输入的方法——以“前后，左右”为例

### Input

- 通过在 **Project Settings** 中的 **Input Manager** 可以获取每个输入的值，在脚本里就可以通过Input.GetAxis("String")来获取。

### Horizontal

- 在input中决定了方向，可以通过Input.GetAxis("Horizontal")获取后，用transform.Rotate()来更改方向。
- 值为0 1 0，以float方式存储。

### Vertical

- 在input中决定了前进or后退，可以通过Input.GetAxis("Vertical")获取后，用transform.Translate()来更改前后。
- 值为-1 1，以float方式存储。

### Time.deltaTime

留坑，第二天再写

### Vertical3

留坑