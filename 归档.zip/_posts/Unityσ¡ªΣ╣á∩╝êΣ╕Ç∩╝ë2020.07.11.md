---
title: Unity学习（一） 2020.07.11

date: 2020-07-11 20:00:04
tags:

- Unity
- 暑期学习

---
拿暑期的时间系统的学一下U3D和C#，之前都是用什么学什么，知识点都散。之前的swift复习就鸽了，因为整理到后面发现完全没必要写下来，最后考的也挺好，就不写了。
<!-- more -->
学习资料是看的千锋初级，讲了一段u3d基础功能后就开始C#的进阶课程了。
> * 链接: https://pan.baidu.com/s/1lZn1hqRCFF7rVGib0G2pgg 
> * 提取码: kq6z

以下为本日所学：
---------

# 工具栏

`ducplicate`  复制 和 `copy`  拷贝 不一样

`Edit` 

`Preference` 偏好设置

`Assests` 资源

`show in explorer` 在文件管理器这打开

`import Package` 导入资源包

`GameObject` 游戏对象

`Component` 组件

`Window`  unity 面板窗口

`Help` 

# 面板

`Layout` 布局方式 

`Revert Factory`  恢复出厂设置

`Project` 项目面板——管理一个项目中用到的所有资源文件

`Scene` 场景面板——用来编辑场景，列出场景中所有的对象

`Game` 游戏面板——玩家看到的面板，由场景中的摄像机拍摄到的 

`Hierarchy` 层级面板——管理所有中的游戏对象，将所有的游戏对象以层级的形式列举出来

`Inspector` 检视面板——显示一个游戏对象身上的组件；显示组件中的属性

# 空间坐标系

`坐标系`  unity：左手坐标系，数学：右手坐标系

# 场景中的操作

## 旋转

`旋转`  alt+左键 or 右键

`右上角的锁`  锁定旋转

## 缩放

`缩放`  鼠标滚轮

## 快速的在场景中找到指定的游戏对象

- 在Hierarchy中找到对象，双击
- 在Hierarchy中单机选中，在场景中按F

## 拖动场景

`拖动` 按住鼠标中键；Q

## 左上角的工具——快捷键依次为QWERT

`手` 移动

`Move tool` 移动物体 影响Transform.Position

`Rotate Tool` 旋转 影响Transform.Rotation

`Scale Tool` 缩放 影响Transform.Scale

`Rect Tool` 缩放

## 切换中心点

- Pivot 选中的游戏对象中心点
- Center 所有选中的对象的计算出来的中心点
- 快捷键位：Z

## 切换坐标系

- Global 采用世界坐标——东南西北
- Local 采用自身坐标——前后左右
- 快捷键：X

# GameObject

## 父子物体关系

- 一个游戏对象，只能有一个父物体
- 一个游戏对象，可以有无数个子物体
- 子物体的操作不会对父物体产生影响，反之则会
- 子物体的位置、旋转、缩放都是相对于父物体的

# 组件

- 具有一定功能的集合
- 如果希望游戏对象具有什么功能，只需要给这个游戏对象添加相应的组件即可

## Mesh Filter

- 网格过滤器，决定了一个对象的形状

## Mesh Renderer

- 决定了一个游戏对象的外观展示

# 材质 Material

- 决定一个对象的外观
