---
title: 从网易云导入音乐到Apple Music
date: 2019-07-22 19:47:13
tags:
- 日常
- 小技巧
---
随着`网易云音乐`的版权越来越少，功能越来越臃肿，歌词被和谐，我决定换到`Apple Music`一段时间试试，但由于网易云每个歌单都有好几百首音乐，如果一首一首的导入太麻烦了，便开始研究如何将歌单完美导入。
<!-- more --> 
采用的方法是：`Apple Music`资料库里有的音乐，使用`TunemyMusic`来导入，库里没有的音乐使用`iCloud音乐库`来进行云播放。

下面是具体方法：

步骤一：下载浏览器的油猴插件
---------
![header]( /img/wa11.png)
> * 油猴安装教程 ：https://zhuanlan.zhihu.com/p/52182666

步骤二：安装油猴脚本，并启动
---------
![header]( /img/wa12.png)
> * 安装网址 ：http://t.cn/AilEhyvb

步骤三：网易云分享歌单，导出txt格式文件
---------
![header]( /img/wa13.png)
以链接的方式分享你想要导入`Apple Music`的歌单，用安装了油猴脚本的浏览器打开，选择导出。
![header]( /img/wa14.png)
下载后打开，会获得如下所示：
![header]( /img/wa15.png)

步骤四：使用TunemyMusic来导入音乐到Apple Music
---------
> * 进入官网 ：https://www.tunemymusic.com/zh-cn/

在来源选择中选择`从文本`：
![header]( /img/wa16.png)
如图所示，将刚才的文本内容粘贴至此：
![header]( /img/wa17.png)
选择目的地为`Apple Music`，并登录`Apple ID`：
![header]( /img/wa18.png)
登陆完成就可以看到已经开始向`Apple Music`添加了，剩下的等着就好。
![header]( /img/wa19.png)
其余导入失败可以从网易云下载，使用`iTunes`播放，就会自动添加进`iCloud音乐库`了。
![header]( /img/wa110.png)