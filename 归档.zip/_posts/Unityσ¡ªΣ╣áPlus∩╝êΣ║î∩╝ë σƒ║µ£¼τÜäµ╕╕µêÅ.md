---
title: Unity学习Plus（二） 基本的游戏
date: 2020-07-14 18:13:35
tags:

- Unity
- 暑期学习

---
今天的练习关于一个小游戏，通过这个小游戏掌握一些基本的方法。
<!-- more -->
## Unity官方课程 Unit 2

## 一点微小的知识

- 通过Gizmos调整摄像机在Scene中的范围。
- 在Scene中，使用 `鼠标右键` + `滚轮` 可以调整用WASD控制试图的时候的移动速度。
- 在调整三维向量时候，为了避免搞晕自己，可以切换到各个轴视角调整，按住 `Ctrl` 后可以进行等边调整。
- 拖拽预制体时尽量在Hierarchy面板中，如果在Scene中很可能是悬空的。

## 游戏实现

游戏中`自动生成`朝向Player奔跑的“动物”，通过`左右移动`和`空格`发射食物，使其消失。

## PlayerController

```csharp
public class PlayerControllor : MonoBehaviour
{
    public float speed = 40f;
    public float horizontalInput;
    public float xRange;
    public GameObject pizzaPrefeb;

    void Update()
    {
        horizontalInput = Input.GetAxisRaw("Horizontal");
        transform.Translate(Vector3.right * horizontalInput * Time.deltaTime * speed);
				//设定边界 原理：通过给判断人物transform中position的x大于边界，如果成立就把边界的值赋给其，已达到边界限制的作用。
        if (transform.position.x > xRange)
        {
            transform.position = new Vector3(23, 0, 0);
        }
        if (transform.position.x < -xRange) 
        {
            transform.position = new Vector3(-23, 0, 0);
        }

        if (Input.GetKeyDown(KeyCode.Space)) 
        {
            Instantiate(pizzaPrefeb, transform.position, pizzaPrefeb.transform.rotation);
        }

    }
}
```

### GetAxisRaw

- 与GetAxis不同的是，GetAxisRaw是从键盘获取 0，-1，0三个数，而GetAxis是获取-1，1之间的一个数，类似开车或者刹车。

### Input.GetKeyDown

- 当用户按下指定名称的按键时的那一帧返回true
- 要在Update方法中调用这个方法，此后每一帧重置状态时，它将不会返回true除非用户释放这个按钮然后重新按下它

## MoveForward

```csharp
public class MoveForward : MonoBehaviour
{
    public float speed = 40f;

    void Update()
    {
        transform.Translate(Vector3.forward * speed * Time.deltaTime); //forward .z

        //设置上下的边界
        if (transform.position.z < -107f )
        {
            Destroy(gameObject);
        }
    }
    public void OnCollisionEnter(Collision collision)
    {
        Destroy(collision.gameObject);
        Destroy(gameObject);
    }
}
```

## OnCollisionEnter

- OncollisionEnter方法要求碰撞的发起方必须有钢体，只要碰撞双方一个有钢体，则二者都会触发OncollisionEnter方法。所以钢体是判断是否碰撞的标志。
- collision.gameObject为被碰撞对象。

### 有钢体的情况

A对象与B对象相撞后，无论是谁先撞上的谁，都可以触发OncollisionEnter方法。

### 没有钢体的情况

A有钢体，B没有，A去撞B，则AB都会触发OncollisionEnter方法。

A有钢体，B没有，B来撞A，则AB都不会触发OncollisionEnter方法。

### Destroy

- Destroy(gameObject)，用来摧毁一个游戏对象。

## SpawnManager

```csharp
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public GameObject[] animPrefab;
    public int index;

    public float xRange;
    void Start()
    {
        InvokeRepeating(nameof(SpawnAnimal),2,1);
    }

    void SpawnAnimal() 
    {
        index = Random.Range(0, animPrefab.Length);
        float xPosition = Random.Range(xRange, -xRange);

        Instantiate(animPrefab[index], new Vector3(xPosition, 0f, 30f), animPrefab[index].transform.rotation);
    }
}
```

### Invoke

```csharp
Invoke(methodName: string, time: float): void;
methodName:方法名
time:多少秒后执行
```

### InvokeRepeating

```csharp
InvokeRepeating(methodName: string, time: float, repeatRate: float): void;
methodName:方法名
time:多少秒后执行
repeatRate：重复执行间隔
```

### Instantiate

- Instantiate(gameObject)，创建游戏对象。