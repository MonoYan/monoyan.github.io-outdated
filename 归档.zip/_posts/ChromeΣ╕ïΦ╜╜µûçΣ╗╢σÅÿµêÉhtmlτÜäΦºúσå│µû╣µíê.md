---
title: Chrome下载文件变成html的解决方案
date: 2020-07-14 12:06:47
tags:
- 问题解决
- 小技巧

---
最近发现windows那台电脑上的Chrome无论下载什么都会变成xxx.html，即便是另存为也是一样的情况。
<!-- more -->
解决方案：按住`Alt`键位再点击下载就可以了。

