---
title: Swift基础语法（一）
date: 2020-07-07 15:29:26
tags:
- Swift
---
## 期末考试周

整理一下考试用到的Swift的基本语法，权当复习，一共会有四篇。本篇包含了注释，变量，常量，声明方式，数据类型，元祖，数组，字典。

<!-- more -->
注释
---------
Swift有两种注释方式:
`单行注释`

```Swift
// 我是单行注释
```

`多行注释`

```swift
/* 
我是多行注释
我是第二行
*/
```

变量与常量
---------
常量关键字为 `let` 常量不支持再进行赋值操作

```Swift
let PI = 3.1415926 
```

此时如果再给PI赋值，就会报错，这时候我们可以使用变量 `var`

```Swift
var wage = 500

wage = 700 //将700再次赋值给wage，此时不会报错
```

##声明方式：

`隐式声明变量`

```swift
var name = value
```

`显示声明变量`

```swift
var name:type = value
```
命名规则
---------
如果没有一个有效的命名，回过头来就很可能忘了这个变量或者常量是做什么使用的，所以这时候我们需要**命名规范**

`小驼峰命名` 除了首个单词,其他单词首字母大写,拼接起来
``` Swift
var currentBuildingHeight = 26 
```

`大驼峰命名`或者叫`帕斯卡命名` 所有的单词都首字母大写
``` Swift
var CurrentBuildingHeight = 26
```

`下划线命名法` 用下划线🔗 所有单词
``` Swift
var current_building_height = 26 
```

`常量的命名方式`
所有字母全部大些，并皆适用下划线连接单词，用尽可能的名称描述出常量的意义

``` Swift
let BUILDING_LEVEL_HEIGHT = 3 //使用常量 描述层高
```

打印方式
---------
``` Swift
let BUILDING_LEVEL_HEIGHT = 3

print(BUILDING_LEVEL_HEIGHT)
debugPrint(BUILDING_LEVEL_HEIGHT)
dump(BUILDING_LEVEL_HEIGHT)   //dump在打印class的时候，会输出class中的全部属性
```

基本的数据类型
---------
**1、布尔类型 Bool**

`Bool类型`用来表示true和false，不过和c语言中**不一样**的是，swift对于bool的定义只有true和false，不能通过1和0来代替。

```Swift
var bol:Bool = true //使用显式声明变量 bol，bol为true

if(bol)
{
	print("1") //因为bol为true，所以执行语句print，输出1
}
```

**2、整形 Int**

`Int类型`用来表示整数

在32位系统中,Int类型代表了Int32,表示在内存中他存储的是32位长.
在64位系统中,Int类型代表了Int64,表示在内存中他存储的是64位长.

```Swift
var Interg:Int = Int.max
var Max:Int64 = Int64.max //显示64位内存中储存的Int64长度 9223372036854775807
```

以Int8为例，Int8的最大值应该是128，但因为会有来表示的符号的最高位，所以最大值为127
```Swift
var num:Int8 = Int8.max //127
```

无符号Int8,没有位数限制，故为255
```Swift
var num:UInt8 = UInt8.max //255
```

**3、浮点型 Float\Double**

`浮点型`用来存放小数，其中Float为单精度，存放32位；Double为双精度，存放64位
Double可以保证15位小数京都，Float保证6位小数精度，如果超出精确度会有问题

```swift
var float:Float = 0.123456
var double:Double = 0.012345678912345
```

**4、字符与字符串 String\Char**
`String`用来存放一串字符，可以是字母，数字，符号等，使用`“”`双引号赋值。

```swift
let str:String = "hello，world！"
```

`Char`用来存放字符，是Charactor的缩写,同样用双引号赋值
```swift
let char:String = "H"
```

**部分转义**
因为在一些情况下，直接使用符号可能会造成混乱导致编译失败，或者我们要实现别的功能，我们可以使用\来进行转义
```swift
 \t 制表
 \r 回车
 \n 换行
 \' 单引号
 \'' 双引号
 \\ 反斜杠
 \0 空字符
```

元祖 Tuple
---------
`元祖`是多个元素相关联的一个对象，Tuple（Type1,Type2,...）

`匿名元祖`
```swift
var tuple1:(String,Int,Bool) = ("张三",23,true)

//匿名元祖只能点下标来取值
tuple1.0 

//输出为张三
```

`非匿名元祖` 优先使用
```swift
var tuple2:(name:String,age:Int,gender:Bool) = (name:"李四",age:24,gender:true)

tuple2.name

//输出为李四
```

数组 Array
---------
`数组`是一个同种类型的集合
数组的一种声明方式
```swift
var array:Array<Int> = Array<Int>()
```

数组的声明方式2
```swift
var array2:[Int] = [Int]()
```

直接声明
```swift
var array3 = [1,2,4,5]
```

数组如何添加
```swift
array.append(0)
array.append(6)
array.append(8)
array.append(5)
```
**数组的下标(索引) 是从0开始计算的**

数组的访问
```swift
array[0]
array[1]
array[3]
```

数组的插入

```swift
array.insert(3, at: 0) //把数字3插入下标0
```

数组删除
```swift
array.remove(at: 3)
```

数组的排序
```swift
array.sort(by:>)
```

**多维数组**
声明方式1:
```swift
var multiArray:[[Int]] = [[Int]]()
```

声明方式2:
```swift
var multiArray2 = [[1,2,3,4],[5,6,7,8]]
```

字典 Dictionary
---------
`Dictionary`是以键值对的方式存储数据

```swift
var dic:Dictionary<String,Int> = Dictionary<String,Int>()

//新华字典 用名字找页号的例子
dic["安"] = 7
dic["周"] = 361
```
字典如何移除
```swift
dic.remove(at: dic.index(forKey: "周")!)
```

显示字典的键、值
```swift
dic.values
dic.keys
```






