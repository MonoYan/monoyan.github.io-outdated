---
title: Unity学习（二） 2020.07.12
date: 2020-07-12 19:57:38
tags:

- Unity
- 暑期学习

---
（题外话，早点起床会觉得一天特别充实！）
接上篇，今日学习为：
---------
<!-- more -->
## 预制体

- 将某个游戏对象以文件的形式存储起来
- 作用：用来批量管理游戏对象；修改预制体的缩放，会对所有的游戏对象都产生影响；给预制体加上组件，所有的对象都会有添加组件

`Select` 快速找到这个对象对应的预制体

**Overrides**

`Revert` 将游戏对象的组件及属性还原为预制体中的定义

`Apply` 将对象的属性应用到预制体

## 资源包

- 可以把项目中的资源打包导出
- 如何打包Project下 → Export packages
- 如何导入Project下 → Import packages；拖进project；直接双击资源
- 标准资源包：Standard Assest 路径Unity/Editor/Standard

## 地形 Terrain

组件

- Raise/Lower Terrain——升高or下降的地形
    - Brushes 笔刷
    - `Opacity` 笔刷的硬度，决定一次抬高的高度
    - 按住 `Shift` 可以降低，但最低是和terrain平行
- Paint Height——设置一个高度，然后将高于这个高度的部分刷低，将低于的这个高度的部分刷高
    - Hold on `shift` 可以从已有高度选取高度
    - Flatten 将设定的高度应用给整个地形
- Smooth Height——平滑地形，使棱角分明的地方变得圆润平滑
- Paint Texture——绘制地面纹理
    - 第一个添加的纹理会作用给全部的地形
- Place Trees
    - Density 密度
- Paint Detail
- Settings

## 钢体 Rigidbody

模拟现实中的物理效果

- Mass 质量
- Drag  拉力——运动方向的阻力
- Angular Drag 旋转的拉力
- Use Gravity 使用重力
- Is Kinematic 开启运动学
- Interpolate 插值
- Collision Detection 碰撞检测
- Constraints 约束
    - Freeze Position
    - Freeze Potation

## 碰撞体组件 Collider

两个物体发生碰撞，实际上产生的是两个碰撞体

## 物理材质 Physics Material

如果没有设置物理材质，摩擦力为无限大，弹力为0

- Dynamic Fricction 动态摩擦力
- Static Friction 静态摩擦力 没有相对位移时候的摩擦力
- Bounciness 弹力
- Friction Combine 阻隔摩擦力
- Bounce Combine 弹力摩擦力
